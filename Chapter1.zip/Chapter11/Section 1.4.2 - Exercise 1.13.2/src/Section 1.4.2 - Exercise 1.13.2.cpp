//============================================================================
// Name        : 2.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

int main()
{
  for (int num { 10 }; num >= 0; --num)
  {
    std::cout << num << std::endl;
  }
  return 0;
}
