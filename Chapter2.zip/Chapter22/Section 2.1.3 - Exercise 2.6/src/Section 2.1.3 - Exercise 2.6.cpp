//============================================================================
// Name        : 6.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

int main()
{
  int month = 9, day = 7;
  int month2 = 09, day1 = 07;

  std::cout << month << " " << month2 << " " << day << " " << day1 << std::endl;
  return 0;
}
