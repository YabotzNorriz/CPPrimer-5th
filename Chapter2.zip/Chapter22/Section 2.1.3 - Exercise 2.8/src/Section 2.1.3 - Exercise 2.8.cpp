//============================================================================
// Name        : 8.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

int main()
{
  std::cout << "\062\115\012";
  std::cout << "\062\t\115\012";
  return 0;
}
