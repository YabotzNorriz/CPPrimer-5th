//============================================================================
// Name        : 9.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>

int main()
{
  std::cin >> int input_value;
  int i = { 3.14 };
  double salary = wage = 9999.99;
  int i = 3.14;
  return 0;
}
